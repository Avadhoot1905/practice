package com.demo.order;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.*;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Map;

/**
 * DB-PER-SERVICE: Order Service gets its own DataSource, EntityManagerFactory,
 * and TransactionManager pointing at H2 "ordersdb" — completely isolated from
 * the User Service's "usersdb".
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = "com.demo.order",
        entityManagerFactoryRef = "orderEntityManagerFactory",
        transactionManagerRef  = "orderTransactionManager"
)
public class OrderDataSourceConfig {

    /** Reads order-datasource.* from application.yml */
    @Bean
    @ConfigurationProperties(prefix = "order-datasource")
    public DataSource orderDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean orderEntityManagerFactory(
            EntityManagerFactoryBuilder builder,
            @Qualifier("orderDataSource") DataSource ds) {

        return builder
                .dataSource(ds)
                .packages("com.demo.order")
                .persistenceUnit("orders")
                .properties(Map.of(
                        "hibernate.hbm2ddl.auto",            "create-drop",
                        "hibernate.dialect",                 "org.hibernate.dialect.H2Dialect",
                        "hibernate.show_sql",                "true"
                ))
                .build();
    }

    @Bean
    public PlatformTransactionManager orderTransactionManager(
            @Qualifier("orderEntityManagerFactory") EntityManagerFactory emf) {
        return new JpaTransactionManager(emf);
    }
}
