package com.demo.user;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@Service
@RequiredArgsConstructor
class UserService {
    private final UserRepository repo;

    public List<User> findAll() { return repo.findAll(); }

    public User findById(Long id) {
        return repo.findById(id).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found: " + id));
    }

    public User create(User user) {
        if (repo.existsByEmail(user.getEmail()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email exists: " + user.getEmail());
        return repo.save(user);
    }

    public User update(Long id, User patch) {
        User u = findById(id);
        u.setName(patch.getName());
        u.setEmail(patch.getEmail());
        return repo.save(u);
    }

    public void delete(Long id) { repo.deleteById(id); }
}

@RestController
@RequestMapping("/internal/users")
@RequiredArgsConstructor
class UserController {
    private final UserService service;

    @GetMapping               public List<User> all()                          { return service.findAll(); }
    @GetMapping("/{id}")      public User one(@PathVariable Long id)           { return service.findById(id); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
                              public User create(@RequestBody User u)          { return service.create(u); }
    @PutMapping("/{id}")      public User update(@PathVariable Long id, @RequestBody User u) { return service.update(id, u); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
                              public void delete(@PathVariable Long id)        { service.delete(id); }
}
