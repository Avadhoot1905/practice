package com.demo.order;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
class OrderService {
    private final OrderRepository repo;
    public List<Order> findAll()               { return repo.findAll(); }
    public Order findById(Long id)             { return repo.findById(id).orElseThrow(); }
    public List<Order> findByUser(Long userId) { return repo.findByUserId(userId); }
    public Order create(Order order)           { order.setCreatedAt(LocalDateTime.now()); return repo.save(order); }
    public void delete(Long id)                { repo.deleteById(id); }
}

@RestController
@RequestMapping("/internal/orders")
@RequiredArgsConstructor
class OrderController {
    private final OrderService service;
    @GetMapping                   public List<Order> all()                          { return service.findAll(); }
    @GetMapping("/{id}")          public Order one(@PathVariable Long id)           { return service.findById(id); }
    @GetMapping("/user/{userId}") public List<Order> byUser(@PathVariable Long uid) { return service.findByUser(uid); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
                                  public Order create(@RequestBody Order o)         { return service.create(o); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
                                  public void delete(@PathVariable Long id)         { service.delete(id); }
}
