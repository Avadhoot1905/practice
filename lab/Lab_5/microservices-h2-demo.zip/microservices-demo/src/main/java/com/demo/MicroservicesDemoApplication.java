package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Single-JAR microservices demo.
 *
 * Simulated architecture (all in one process for demo simplicity):
 *
 *   ┌─────────────────────────────────────────────────────────┐
 *   │                     API GATEWAY                         │
 *   │  /api/users/**  →  UserService  (H2: usersdb)           │
 *   │  /api/orders/** →  OrderService (H2: ordersdb)          │
 *   │           ↑ wrapped with Circuit Breaker                │
 *   └─────────────────────────────────────────────────────────┘
 *
 * In production each service would be a separate Spring Boot JAR
 * with its own database instance. The patterns are identical.
 */
@SpringBootApplication
public class MicroservicesDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(MicroservicesDemoApplication.class, args);
    }
}
