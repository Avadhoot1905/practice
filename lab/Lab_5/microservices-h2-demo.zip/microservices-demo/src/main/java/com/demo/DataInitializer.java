package com.demo;

import com.demo.user.UserRepository;
import com.demo.order.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Seeds sample data into BOTH H2 databases on startup.
 * Demonstrates that each service's DB is populated independently.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository  userRepo;
    private final OrderRepository orderRepo;

    @Override
    public void run(String... args) {
        log.info("=== Seeding User Service DB (usersdb) ===");

        var alice = com.demo.user.User.builder()
                .name("Alice").email("alice@example.com").build();
        var bob = com.demo.user.User.builder()
                .name("Bob").email("bob@example.com").build();
        userRepo.save(alice);
        userRepo.save(bob);
        log.info("Users seeded: {}", userRepo.findAll());

        log.info("=== Seeding Order Service DB (ordersdb) ===");

        orderRepo.save(com.demo.order.Order.builder()
                .userId(1L).product("Spring Boot Book").qty(1).build());
        orderRepo.save(com.demo.order.Order.builder()
                .userId(1L).product("Mechanical Keyboard").qty(2).build());
        orderRepo.save(com.demo.order.Order.builder()
                .userId(2L).product("Monitor").qty(1).build());
        log.info("Orders seeded: {}", orderRepo.findAll());

        log.info("""
            ╔══════════════════════════════════════════════════════════════╗
            ║              Microservices Demo — Ready!                     ║
            ╠══════════════════════════════════════════════════════════════╣
            ║  API Gateway:                                                ║
            ║    GET  http://localhost:8080/api/users                      ║
            ║    POST http://localhost:8080/api/users                      ║
            ║    GET  http://localhost:8080/api/orders                     ║
            ║    GET  http://localhost:8080/api/orders/user/1              ║
            ║    POST http://localhost:8080/api/orders                     ║
            ║                                                              ║
            ║  Circuit Breaker status:                                     ║
            ║    GET  http://localhost:8080/actuator/health                ║
            ║                                                              ║
            ║  H2 Console (usersdb):                                       ║
            ║    http://localhost:8080/h2-console                         ║
            ║    JDBC URL: jdbc:h2:mem:usersdb                            ║
            ╚══════════════════════════════════════════════════════════════╝
            """);
    }
}
