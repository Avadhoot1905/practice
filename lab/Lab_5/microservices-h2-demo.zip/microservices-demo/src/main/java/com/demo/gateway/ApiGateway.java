package com.demo.gateway;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.*;

// ─────────────────────────────────────────────────────────────────────────────
// REST TEMPLATE CONFIG
// ─────────────────────────────────────────────────────────────────────────────
@Configuration
class GatewayConfig {
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// GATEWAY SERVICE — wraps calls to User Service with @CircuitBreaker
// ─────────────────────────────────────────────────────────────────────────────
@Service
@RequiredArgsConstructor
@Slf4j
class UserGatewayService {

    private final RestTemplate rest;
    private static final String BASE = "http://localhost:8080/internal/users";

    // ── Circuit Breaker wraps each downstream call ───────────────────────────

    @CircuitBreaker(name = "userService", fallbackMethod = "usersFallback")
    public ResponseEntity<Object> getAll() {
        return rest.getForEntity(BASE, Object.class);
    }

    @CircuitBreaker(name = "userService", fallbackMethod = "userFallback")
    public ResponseEntity<Object> getOne(Long id) {
        return rest.getForEntity(BASE + "/" + id, Object.class);
    }

    @CircuitBreaker(name = "userService", fallbackMethod = "userFallback")
    public ResponseEntity<Object> create(Map<String, Object> body) {
        return rest.postForEntity(BASE, body, Object.class);
    }

    @CircuitBreaker(name = "userService", fallbackMethod = "userFallback")
    public ResponseEntity<Object> update(Long id, Map<String, Object> body) {
        rest.put(BASE + "/" + id, body);
        return ResponseEntity.ok(Map.of("message", "updated"));
    }

    @CircuitBreaker(name = "userService", fallbackMethod = "userFallback")
    public ResponseEntity<Object> delete(Long id) {
        rest.delete(BASE + "/" + id);
        return ResponseEntity.noContent().build();
    }

    // ── Fallbacks ────────────────────────────────────────────────────────────

    public ResponseEntity<Object> usersFallback(Exception ex) {
        log.warn("[CB:userService] fallback triggered: {}", ex.getMessage());
        String reason = ex instanceof CallNotPermittedException
                ? "Circuit OPEN — User Service unavailable"
                : "User Service error: " + ex.getMessage();
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(Map.of("error", reason, "fallback", true));
    }

    public ResponseEntity<Object> userFallback(Long id, Exception ex) {
        log.warn("[CB:userService] fallback triggered for id={}: {}", id, ex.getMessage());
        String reason = ex instanceof CallNotPermittedException
                ? "Circuit OPEN — User Service unavailable"
                : "User Service error: " + ex.getMessage();
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(Map.of("error", reason, "fallback", true));
    }

    public ResponseEntity<Object> userFallback(Map<String, Object> body, Exception ex) {
        return usersFallback(ex);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// GATEWAY SERVICE — wraps calls to Order Service with @CircuitBreaker
// ─────────────────────────────────────────────────────────────────────────────
@Service
@RequiredArgsConstructor
@Slf4j
class OrderGatewayService {

    private final RestTemplate rest;
    private static final String BASE = "http://localhost:8080/internal/orders";

    @CircuitBreaker(name = "orderService", fallbackMethod = "ordersFallback")
    public ResponseEntity<Object> getAll() {
        return rest.getForEntity(BASE, Object.class);
    }

    @CircuitBreaker(name = "orderService", fallbackMethod = "orderFallback")
    public ResponseEntity<Object> getOne(Long id) {
        return rest.getForEntity(BASE + "/" + id, Object.class);
    }

    @CircuitBreaker(name = "orderService", fallbackMethod = "ordersFallback")
    public ResponseEntity<Object> getByUser(Long userId) {
        return rest.getForEntity(BASE + "/user/" + userId, Object.class);
    }

    @CircuitBreaker(name = "orderService", fallbackMethod = "ordersFallback")
    public ResponseEntity<Object> create(Map<String, Object> body) {
        return rest.postForEntity(BASE, body, Object.class);
    }

    @CircuitBreaker(name = "orderService", fallbackMethod = "orderFallback")
    public ResponseEntity<Object> delete(Long id) {
        rest.delete(BASE + "/" + id);
        return ResponseEntity.noContent().build();
    }

    // ── Fallbacks ────────────────────────────────────────────────────────────

    public ResponseEntity<Object> ordersFallback(Exception ex) {
        log.warn("[CB:orderService] fallback: {}", ex.getMessage());
        String reason = ex instanceof CallNotPermittedException
                ? "Circuit OPEN — Order Service unavailable"
                : "Order Service error: " + ex.getMessage();
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(Map.of("error", reason, "fallback", true));
    }

    public ResponseEntity<Object> orderFallback(Long id, Exception ex) {
        return ordersFallback(ex);
    }

    public ResponseEntity<Object> orderFallback(Map<String, Object> body, Exception ex) {
        return ordersFallback(ex);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// API GATEWAY CONTROLLER — the only public-facing surface
// ─────────────────────────────────────────────────────────────────────────────
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
class ApiGatewayController {

    private final UserGatewayService  users;
    private final OrderGatewayService orders;

    // ── User endpoints ───────────────────────────────────────────────────────

    @GetMapping("/users")
    public ResponseEntity<Object> getUsers() {
        log.debug("[Gateway] GET /api/users");
        return users.getAll();
    }

    @GetMapping("/users/{id}")
    public ResponseEntity<Object> getUser(@PathVariable Long id) {
        log.debug("[Gateway] GET /api/users/{}", id);
        return users.getOne(id);
    }

    @PostMapping("/users")
    public ResponseEntity<Object> createUser(@RequestBody Map<String, Object> body) {
        log.debug("[Gateway] POST /api/users body={}", body);
        return users.create(body);
    }

    @PutMapping("/users/{id}")
    public ResponseEntity<Object> updateUser(@PathVariable Long id,
                                             @RequestBody Map<String, Object> body) {
        log.debug("[Gateway] PUT /api/users/{}", id);
        return users.update(id, body);
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<Object> deleteUser(@PathVariable Long id) {
        log.debug("[Gateway] DELETE /api/users/{}", id);
        return users.delete(id);
    }

    // ── Order endpoints ──────────────────────────────────────────────────────

    @GetMapping("/orders")
    public ResponseEntity<Object> getOrders() {
        log.debug("[Gateway] GET /api/orders");
        return orders.getAll();
    }

    @GetMapping("/orders/{id}")
    public ResponseEntity<Object> getOrder(@PathVariable Long id) {
        log.debug("[Gateway] GET /api/orders/{}", id);
        return orders.getOne(id);
    }

    @GetMapping("/orders/user/{userId}")
    public ResponseEntity<Object> getOrdersByUser(@PathVariable Long userId) {
        log.debug("[Gateway] GET /api/orders/user/{}", userId);
        return orders.getByUser(userId);
    }

    @PostMapping("/orders")
    public ResponseEntity<Object> createOrder(@RequestBody Map<String, Object> body) {
        log.debug("[Gateway] POST /api/orders body={}", body);
        return orders.create(body);
    }

    @DeleteMapping("/orders/{id}")
    public ResponseEntity<Object> deleteOrder(@PathVariable Long id) {
        log.debug("[Gateway] DELETE /api/orders/{}", id);
        return orders.delete(id);
    }

    // ── Gateway health ───────────────────────────────────────────────────────

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of(
                "gateway", "UP",
                "services", List.of("userService", "orderService"),
                "cbStatus", "See /actuator/health for circuit breaker state"
        );
    }
}
